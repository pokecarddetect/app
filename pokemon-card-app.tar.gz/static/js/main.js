/**
 * Main JavaScript functionality for Pokémon Card Detector
 * Handles file upload, drag & drop, preview, and form interactions
 */

// File upload handling
let selectedFile = null;

/**
 * Handle file selection from input or drag & drop
 */
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        processSelectedFile(file);
    }
}

/**
 * Handle drag over event for upload area
 */
function handleDragOver(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.classList.add('dragover');
}

/**
 * Handle drag leave event for upload area
 */
function handleDragLeave(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.classList.remove('dragover');
}

/**
 * Handle file drop event
 */
function handleDrop(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.classList.remove('dragover');
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        const file = files[0];
        
        // Update the file input
        const fileInput = document.getElementById('card_image');
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;
        
        processSelectedFile(file);
    }
}

/**
 * Process and validate selected file
 */
function processSelectedFile(file) {
    // Validate file type
    const allowedTypes = ['image/png', 'image/jpg', 'image/jpeg'];
    if (!allowedTypes.includes(file.type)) {
        showAlert('Invalid file type. Please select a PNG, JPG, or JPEG image.', 'danger');
        return;
    }
    
    // Validate file size (16MB limit)
    const maxSize = 16 * 1024 * 1024; // 16MB in bytes
    if (file.size > maxSize) {
        showAlert('File is too large. Please select an image smaller than 16MB.', 'danger');
        return;
    }
    
    selectedFile = file;
    showFilePreview(file);
    enableSubmitButton();
}

/**
 * Show file preview with image and info
 */
function showFilePreview(file) {
    const uploadContent = document.getElementById('uploadContent');
    const previewArea = document.getElementById('previewArea');
    const previewImage = document.getElementById('previewImage');
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    
    // Hide upload content and show preview
    uploadContent.classList.add('d-none');
    previewArea.classList.remove('d-none');
    
    // Create file URL for preview
    const fileURL = URL.createObjectURL(file);
    previewImage.src = fileURL;
    
    // Update file info
    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    
    // Add click handler for image zoom
    previewImage.addEventListener('click', function() {
        openImageModal(fileURL, file.name);
    });
}

/**
 * Clear selected file and reset upload area
 */
function clearFile() {
    const uploadContent = document.getElementById('uploadContent');
    const previewArea = document.getElementById('previewArea');
    const fileInput = document.getElementById('card_image');
    const previewImage = document.getElementById('previewImage');
    
    // Reset file input
    fileInput.value = '';
    selectedFile = null;
    
    // Revoke object URL to free memory
    URL.revokeObjectURL(previewImage.src);
    
    // Show upload content and hide preview
    uploadContent.classList.remove('d-none');
    previewArea.classList.add('d-none');
    
    disableSubmitButton();
}

/**
 * Enable submit button when file is selected
 */
function enableSubmitButton() {
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = false;
    submitBtn.classList.remove('btn-secondary');
    submitBtn.classList.add('btn-primary');
}

/**
 * Disable submit button when no file is selected
 */
function disableSubmitButton() {
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.classList.remove('btn-primary');
    submitBtn.classList.add('btn-secondary');
}

/**
 * Format file size in human readable format
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Show alert message
 */
function showAlert(message, type) {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    
    // Create elements safely to prevent XSS
    const icon = document.createElement('i');
    icon.className = 'fas fa-exclamation-triangle me-2';
    
    const messageText = document.createTextNode(message);
    
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'btn-close';
    closeButton.setAttribute('data-bs-dismiss', 'alert');
    
    alertContainer.appendChild(icon);
    alertContainer.appendChild(messageText);
    alertContainer.appendChild(closeButton);
    
    // Insert alert at the top of the container
    const container = document.querySelector('.container');
    container.insertBefore(alertContainer, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertContainer && alertContainer.parentNode) {
            alertContainer.remove();
        }
    }, 5000);
}

/**
 * Open image in modal for better viewing
 */
function openImageModal(imageURL, imageName) {
    // Remove existing modal if any
    const existingModal = document.getElementById('imageModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal elements safely to prevent XSS
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'imageModal';
    modal.tabIndex = -1;
    
    const modalDialog = document.createElement('div');
    modalDialog.className = 'modal-dialog modal-lg modal-dialog-centered';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    
    const modalHeader = document.createElement('div');
    modalHeader.className = 'modal-header';
    
    const modalTitle = document.createElement('h5');
    modalTitle.className = 'modal-title';
    
    const titleIcon = document.createElement('i');
    titleIcon.className = 'fas fa-image me-2';
    
    const titleText = document.createTextNode(imageName);
    
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'btn-close';
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    
    const modalBody = document.createElement('div');
    modalBody.className = 'modal-body text-center';
    
    const image = document.createElement('img');
    image.src = imageURL;
    image.alt = 'Card preview';
    image.className = 'img-fluid';
    
    // Assemble the modal
    modalTitle.appendChild(titleIcon);
    modalTitle.appendChild(titleText);
    modalHeader.appendChild(modalTitle);
    modalHeader.appendChild(closeButton);
    modalBody.appendChild(image);
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalDialog.appendChild(modalContent);
    modal.appendChild(modalDialog);
    
    // Add modal to page
    document.body.appendChild(modal);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('imageModal'));
    modal.show();
    
    // Clean up when modal is hidden
    document.getElementById('imageModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

/**
 * Form submission handling
 */
document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(event) {
            if (!selectedFile) {
                event.preventDefault();
                showAlert('Please select a card image before submitting.', 'warning');
                return;
            }
            
            // Start scanning animation and delay form submission
            event.preventDefault();
            startScanningAnimation();
            
            // Submit form after animation completes (16 seconds total)
            setTimeout(() => {
                // Actually submit the form now
                uploadForm.submit();
            }, 16000);
        });
    }
    
    // Initialize tooltips if Bootstrap is available
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
});

/**
 * Smooth scrolling for anchor links
 */
document.addEventListener('click', function(event) {
    if (event.target.matches('a[href^="#"]')) {
        event.preventDefault();
        
        const targetId = event.target.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
});

/**
 * Add animation to cards on scroll
 */
function animateOnScroll() {
    const cards = document.querySelectorAll('.card');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
}

// Initialize scroll animations when page loads
document.addEventListener('DOMContentLoaded', animateOnScroll);

/**
 * Enhanced scanning animation with step-by-step progress
 */
function startScanningAnimation() {
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const scanningText = document.getElementById('scanningText');
    const scanningAnimation = document.getElementById('scanningAnimation');
    const scanningImage = document.getElementById('scanningImage');
    const previewImage = document.getElementById('previewImage');
    
    // Update button state
    submitBtn.disabled = true;
    submitText.classList.add('d-none');
    scanningText.classList.remove('d-none');
    
    // Show scanning animation
    scanningAnimation.classList.remove('d-none');
    
    // Set scanning image to preview image
    if (previewImage && previewImage.src) {
        scanningImage.src = previewImage.src;
    }
    
    // Start step-by-step animation with realistic durations matching backend processing
    const steps = [
        { step: 1, duration: 2000, label: 'AI klasifikace' },
        { step: 2, duration: 3000, label: 'OCR analýza textu' },
        { step: 3, duration: 4000, label: 'Porovnání s databází' },
        { step: 4, duration: 2500, label: 'Vysvětlitelná AI' },
        { step: 5, duration: 2000, label: 'Kvalita tisku' },
        { step: 6, duration: 2500, label: 'Geometrická analýza' }
    ];
    
    let currentStep = 0;
    let totalProgress = 0;
    
    function animateStep() {
        if (currentStep < steps.length) {
            const step = steps[currentStep];
            const stepElement = document.querySelector(`[data-step="${step.step}"]`);
            const spinner = document.getElementById(`spinner-${step.step}`);
            
            // Show spinner for current step
            if (spinner) {
                spinner.classList.remove('d-none');
            }
            
            // Highlight current step
            stepElement.classList.add('text-primary', 'fw-bold');
            
            // Update progress bar
            totalProgress = ((currentStep + 1) / steps.length) * 100;
            const progressBar = document.getElementById('scanProgress');
            progressBar.style.width = totalProgress + '%';
            
            setTimeout(() => {
                // Complete current step
                if (spinner) {
                    spinner.classList.add('d-none');
                }
                stepElement.classList.remove('text-primary');
                stepElement.classList.add('text-success');
                // Use safe DOM methods instead of innerHTML
                stepElement.innerHTML = '';
                const icon = document.createElement('i');
                icon.className = 'fas fa-check me-2';
                stepElement.appendChild(icon);
                stepElement.appendChild(document.createTextNode(step.label));
                
                currentStep++;
                
                // Continue to next step or finish
                if (currentStep < steps.length) {
                    setTimeout(animateStep, 300); // Small delay between steps
                } else {
                    // All steps completed - show completion message
                    setTimeout(() => {
                        const progressBar = document.getElementById('scanProgress');
                        progressBar.style.width = '100%';
                        progressBar.classList.add('bg-success');
                        
                        // Update scanning text
                        const scanningText = document.getElementById('scanningText');
                        // Use safe DOM methods instead of innerHTML
                        scanningText.innerHTML = '';
                        const completionIcon = document.createElement('i');
                        completionIcon.className = 'fas fa-check me-2';
                        scanningText.appendChild(completionIcon);
                        scanningText.appendChild(document.createTextNode('Analýza dokončena - načítají se výsledky...'));
                    }, 500);
                }
            }, step.duration);
        }
    }
    
    // Start the animation
    setTimeout(animateStep, 500);
}

/**
 * Copy text to clipboard functionality
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showAlert('Text copied to clipboard!', 'success');
    }).catch(function(err) {
        console.error('Could not copy text: ', err);
        showAlert('Failed to copy text to clipboard.', 'danger');
    });
}

/**
 * Download analysis results as text file
 */
function downloadResults(results) {
    const content = `
Pokémon Card Analysis Results
============================

File: ${results.filename}
Prediction: ${results.ai_prediction}
Confidence: ${results.ai_confidence}%

AI Feature Analysis:
${JSON.stringify(results.ai_features, null, 2)}

OCR Text:
${results.ocr_text}

OCR Issues:
${results.ocr_issues.join('\n')}

Analysis Date: ${new Date().toISOString()}
`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `pokemon-card-analysis-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
}
