# Průvodce nasazením Pokémon Card Authentication App

## Stažení aplikace z Replit
1. V Replit klikněte na tři tečky (...) v levém menu
2. Vyberte "Download as zip"
3. Rozbalte ZIP soubor na svém počítači

## Požadavky na systém
- Python 3.11+
- PostgreSQL databáze
- Tesseract OCR (pro OCR funkcionalita)

## Instalace závislostí
Vytvoř virtualní prostředí a nainstaluj balíčky:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# nebo
venv\Scripts\activate     # Windows

# Nainstaluj balíčky z pyproject.toml
pip install -e .
```

## Prostředí proměnné
Vytvořte `.env` soubor s těmito proměnnými:
```
DATABASE_URL=postgresql://user:password@localhost/pokemon_cards
SESSION_SECRET=your-secret-key-here
FLASK_ENV=production
```

## Databáze setup
1. Vytvořte PostgreSQL databázi
2. Aplikace automaticky vytvoří tabulky při prvním spuštění

## Nasazení možnosti:

### 1. Heroku
```bash
# Nainstaluj Heroku CLI
heroku create your-app-name
heroku addons:create heroku-postgresql:hobby-dev
git push heroku main
```

### 2. Railway
- Připojte GitHub repository
- Nastavte environment proměnné
- Railway automaticky nasadí

### 3. DigitalOcean App Platform
- Nahrajte kód na GitHub
- Vytvořte novou App
- Připojte GitHub repo
- Nastavte environment proměnné

### 4. AWS (EC2)
```bash
# Na EC2 instanci
sudo apt update
sudo apt install python3-pip python3-venv postgresql-client tesseract-ocr
# Zkopírujte soubory a spusťte aplikaci
```

### 5. Docker nasazení
Vytvořte Dockerfile:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install -e .
EXPOSE 5000
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "main:app"]
```

## Spuštění aplikace
```bash
# Lokálně
python main.py

# Produkce s gunicorn
gunicorn --bind 0.0.0.0:5000 main:app
```

## Důležité poznámky:
- Aplikace používá enhanced fallback model (bez TensorFlow)
- PostgreSQL databáze je nutná pro produkci
- Nastavte správné environment proměnné
- Pro HTTPS produkci nastavte reverse proxy (nginx)