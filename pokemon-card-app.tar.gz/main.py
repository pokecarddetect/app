from app import app

if __name__ == '__main__':
    # Run the Flask application on port 5000 for external access
    app.run(host='0.0.0.0', port=5000, debug=True)
